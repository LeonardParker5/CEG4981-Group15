                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3200932
Grippers for robot with 90 degree gears by Isioviel is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

These are the grippers / pincers for my (150g) antweight robot, Tik-Tok.

# Print Settings

Printer Brand: CEL
Printer: Robox
Rafts: No
Supports: Yes
Filament_brand: Hobbyking
Filament_color: Fluorescent Yellow
Filament_material: ABS

Notes: 
I printed at 50% infill to save weight, but the teeth on the servo gear strip very quickly, so I would recommend 100%.

Supports are only needed for servo_gear.stl

# Post-Printing

The servo gear requires a cut down servo horn to function - I glued mine inside.

The hole between the grippers and the top piece takes M2 spacers, which are bolted onto the chassis.

# How I Designed This

I used the SpurGear script in Fusion360 to make the main gear shape at the centre, then extruded at an angle to make a slight bevel, before adding the gripper arms.

I had to make some odd design decisions to make it all fit in the space I had available, and the gears are not perfectly mated (which is likely why they strip so easily), but they do the job.