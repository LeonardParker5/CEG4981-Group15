# To start the server, run `uvicorn server:app --host 0.0.0.0`

from typing import Optional
from fastapi import FastAPI
import uvicorn
from random import randint

app = FastAPI()

@app.get("/")
def read_root():
    return {
        "random1_10": randint(1, 10),
        "random1_100": randint(1, 100)
    }

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0")
    